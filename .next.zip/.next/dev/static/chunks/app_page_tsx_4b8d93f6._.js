(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_96e1261a._.js",
  "static/chunks/_28ebf2f0._.js"
],
    source: "dynamic"
});

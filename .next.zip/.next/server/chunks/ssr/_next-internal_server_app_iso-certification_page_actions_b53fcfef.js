module.exports=[26275,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_iso-certification_page_actions_b53fcfef.js.map
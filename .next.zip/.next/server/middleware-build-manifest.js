globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/a6dad97d9634a72d.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/0487dcf119c456b7.js",
    "static/chunks/1248aa8d9fa140eb.js",
    "static/chunks/a0ec6e22644869d5.js",
    "static/chunks/01bd51e4ce3f19a7.js",
    "static/chunks/2e5b89f46b61d738.js",
    "static/chunks/turbopack-65608634c319167d.js"
  ]
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js"
];